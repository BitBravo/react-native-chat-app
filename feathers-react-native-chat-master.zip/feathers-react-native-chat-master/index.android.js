'use strict';

import React, { AppRegistry } from 'react-native';

import Application from './src/Application';
AppRegistry.registerComponent('FeathersReactNativeChat', () => Application);